#include "cd.h"
#include "tar_manipulation.c"

int cd(char *path){
  if(strcmp(path,"") == 0 || strcmp(path,"/") == 0) return 0;
  /* we're in a tar */
  if(strstr(getenv("TARPATH"),".tar") != NULL){
    /* no tar in a tar */
    if(strstr(path,".tar") != NULL) return -1;
    return 0;
  }
  /* we're not */
  /* we take the first elem in path, enter it and recall on the rest */
  char* elem = strtok(path,"/");
  if(elem == NULL) return -1;
  /* we're trying to enter a tar */
  if(strstr(elem,".tar") != NULL){
    /* a FAKE tar */
    if(!isTar(elem)) return -1;
    char* newpath = getenv("TARPATH");
    newpath = realloc(newpath, strlen(newpath) + strlen(elem) + 1);
    strcat(newpath,elem);
    setenv("TARPATH", newpath,1);
    return cd(path + strlen(elem) + 1);
  }
  /* we're not */
  if(chdir(elem) < 0) return -1;
  return cd(path + strlen(elem) + 1);
}
